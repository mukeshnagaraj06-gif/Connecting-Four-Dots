const rows = 6;
const cols = 7;
let currentPlayer = 'red';
const board = [];
const boardDiv = document.getElementById('board');
const status = document.getElementById('status');

// Initialize board
for (let r = 0; r < rows; r++) {
  board[r] = [];
  for (let c = 0; c < cols; c++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.row = r;
    cell.dataset.col = c;
    boardDiv.appendChild(cell);
    board[r][c] = null;
  }
}

// Handle click
boardDiv.addEventListener('click', (e) => {
  if (!e.target.classList.contains('cell')) return;

  const col = parseInt(e.target.dataset.col);
  for (let r = rows - 1; r >= 0; r--) {
    if (!board[r][col]) {
      board[r][col] = currentPlayer;
      const cell = document.querySelector(`.cell[data-row="${r}"][data-col="${col}"]`);
      cell.classList.add(currentPlayer);

      if (checkWin(r, col)) {
        status.textContent = `${currentPlayer === 'red' ? '🔴' : '🟡'} Wins!`;
        boardDiv.style.pointerEvents = 'none';
      } else {
        currentPlayer = currentPlayer === 'red' ? 'yellow' : 'red';
        status.textContent = `Current Turn: ${currentPlayer === 'red' ? '🔴' : '🟡'}`;
      }
      break;
    }
  }
});

// Win Check
function checkWin(r, c) {
  const directions = [
    [[0, 1], [0, -1]],    // Horizontal
    [[1, 0], [-1, 0]],    // Vertical
    [[1, 1], [-1, -1]],   // Diagonal \
    [[1, -1], [-1, 1]]    // Diagonal /
  ];

  for (const dir of directions) {
    let count = 1;
    for (const [dr, dc] of dir) {
      let rr = r + dr;
      let cc = c + dc;
      while (
        rr >= 0 && rr < rows &&
        cc >= 0 && cc < cols &&
        board[rr][cc] === currentPlayer
      ) {
        count++;
        rr += dr;
        cc += dc;
      }
    }
    if (count >= 4) return true;
  }

  return false;
}
